﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    /// <summary>
    /// Metodo Encargado de Almacenar ,Usar y Enviar los Datos de cada Panel 
    /// </summary>
    public class Datos
    {
        //Declaracion de Variables
        public string NombreCompleto { get; set; }

        public string Sintomas { get; set; }
        public string Tratamiento { get; set; }
        public string Enfermedad { get; set; }
        public double PorcentajeResfriadoComun { get; set; }
        public double PorcentajeAlergia { get; set; }
        public double PorcentajeGripe { get; set; }
        public double PorcentajeSinusitis{ get; set; }
        public double PorcentajeBronquitis { get; set; }
        public double PorcentajeMaximo { get; set; }

        public void CompararPorcentaje()
        {
            PorcentajeMaximo = 0;
            PorcentajeResfriadoComun = 0;
            PorcentajeAlergia = 0;
            PorcentajeGripe = 80;
            PorcentajeSinusitis = 0;
            PorcentajeBronquitis = 0;


            // Compara los porcentajes y encuentra el máximo
            if (PorcentajeResfriadoComun > PorcentajeMaximo)
            {
                PorcentajeMaximo = PorcentajeResfriadoComun;
                Enfermedad = "Resfriado Comun";
            }
            if (PorcentajeAlergia > PorcentajeMaximo)
            {
                PorcentajeMaximo = PorcentajeAlergia;
                Enfermedad = "Alergia";
            }
            if (PorcentajeGripe > PorcentajeMaximo)
            {
                PorcentajeMaximo = PorcentajeGripe;
                Enfermedad = "Gripe";
            }
            if (PorcentajeSinusitis > PorcentajeMaximo)
            {
                PorcentajeMaximo = PorcentajeSinusitis;
                Enfermedad = "Sinusitis";
            }
            if (PorcentajeBronquitis > PorcentajeMaximo)
            {
                PorcentajeMaximo = PorcentajeBronquitis;
                Enfermedad = "Bronquitis";
            }
            tratamiento();
        }
        public void tratamiento()
        {
            if (Enfermedad == "Gripe")
            {
                Sintomas = "Fiebre, dolor de cabeza, fatiga, congestión nasal, dolor de garganta.";
                Tratamiento = "Tratamiento: descanso, líquidos, medicamentos para reducir la fiebre y aliviar los síntomas.";
            }
            else if (Enfermedad == "Resfriado común ")
            {
                Sintomas = "Congestión nasal, estornudos, dolor de garganta, tos, leve malestar general.";
                Tratamiento = "Descanso, líquidos, medicamentos para aliviar la congestión y la tos. ";
            }
            else if (Enfermedad == "Sinusitis")
            {
                Sintomas = "Dolor facial, presión en los senos paranasales, secreción nasal espesa y verde, congestión nasal";
                Tratamiento = "Analgésicos, descongestionantes, irrigación nasal, humidificadores.";
            }
            else if (Enfermedad == "Alergia")
            {
                Sintomas = "Estornudos, picazón en los ojos, congestión nasal, erupciones cutáneas, sibilancias.";
                Tratamiento = "Antihistamínicos, descongestionantes, evitación del alérgeno.";
            }
            else if (Enfermedad == "Bronquitis")
            {
                Sintomas = "Tos persistente, producción de esputo, dificultad para respirar, fatiga, dolor en el pecho. ";
                Tratamiento = "Tratamiento: descanso, líquidos, inhaladores broncodilatadores, medicamentos para aliviar la tos.";
            }

        }

    }
}
