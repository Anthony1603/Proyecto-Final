﻿using BLL;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;
//Referenciar el Metodo BLL
using BLL;
using System.Windows.Forms;

namespace SistemaDiagnosticoMedico
{
    internal class Arbol
    {
        //Propiedades para el Funcionamiento del Arbol
        public string Pregunta { get; set; }
        public Arbol Si { get; set; }
        public Arbol No { get; set; }

        //Variable Objeto del BLL
        private Datos datos;

        public Arbol(string pregunta)
        {
            //Metodo Encargado de la Inicializacion del Arbol
            Pregunta = pregunta;
            Si = null; 
            No = null;

            //Instanciar Objeto BLL
            datos = new Datos();
        }

        public void InicializarArbol()
        {
            // Lógica para Inicializar el Arbol con Preguntas y Relaciones entre Nodos
            if (Pregunta == "¿Has experimentado congestión nasal?")
            {
                //Opciones Segun "Si" o "No"
                Si = new Arbol("¿Has experimentado estornudos frecuentes?");
                No = new Arbol("¿Se le ha presentado una tos persistente?");
              
                // Inicializa el Subárbol con las Respuestas "Sí" o "No"
                Si.InicializarArbol();
                No.InicializarArbol();
            }
            else if (Pregunta == "¿Has experimentado estornudos frecuentes?")
            {
                Si = new Arbol("¿Tiene dolor de garganta?");
                No = new Arbol("¿Tiene fiebre?");
                Si.InicializarArbol();
                No.InicializarArbol();

                //Dar porcentajes
                datos.PorcentajeGripe += 20;
                datos.PorcentajeResfriadoComun += 20;
                datos.PorcentajeSinusitis += 25;
                datos.PorcentajeAlergia += 20;
            }



            //Opciones con estornudos
            //Preguntas de Resfriado Comun
            else if (Pregunta == "¿Tiene dolor de garganta?")
            {
                Si = new Arbol("¿Tiene tos?");
                No = new Arbol("¿Experimenta picazón en los ojos?");
                Si.InicializarArbol(); 
                No.InicializarArbol(); 
            }
            else if (Pregunta == "¿Tiene tos?")
            {
                Si = new Arbol("¿Siente un leve malestar general?");
                No = new Arbol("¿Presenta erupciones cutáneas?");
                Si.InicializarArbol(); 
                No.InicializarArbol(); 
            }
            else if (Pregunta == "¿Siente un leve malestar general?")
            {
                Si = new Arbol("¿?");
                No = new Arbol("¿Ha experimentado sibilancias?");
                Si.InicializarArbol(); 
                No.InicializarArbol(); 
            }



            //Preguntas de Alergia
            else if (Pregunta == "¿Experimenta picazón en los ojos?")
            {
                Si = new Arbol("¿Presenta erupciones cutáneas?");
                No = new Arbol("¿Tiene tos?");
                Si.InicializarArbol();
                No.InicializarArbol(); 
            }
            else if (Pregunta == "¿Presenta erupciones cutáneas?")
            {
                Si = new Arbol("¿Ha experimentado sibilancias?");
                No = new Arbol("¿Siente un leve malestar general?");
                Si.InicializarArbol(); 
                No.InicializarArbol(); 
            }
            else if (Pregunta == "¿Ha experimentado sibilancias?")
            {
                Si = new Arbol("¿?");
                No = new Arbol("¿?");
                Si.InicializarArbol(); 
                No.InicializarArbol();
            }




            //Opciones sin estornudos
            //Preguntas de Gripe
            else if (Pregunta == "¿Tiene fiebre?")
            {
                Si = new Arbol("¿Tiene dolor de cabeza?");
                No = new Arbol("¿Ha experimentado dolor facial?");
                Si.InicializarArbol();
                No.InicializarArbol(); 
            }
            else if (Pregunta == "¿Tiene dolor de cabeza?")
            {
                Si = new Arbol("¿Siente fatiga o cansancio general?");
                No = new Arbol("¿Siente presión en los senos paranasales?");
                Si.InicializarArbol();
                No.InicializarArbol(); 
            }
            else if (Pregunta == "¿Siente fatiga o cansancio general?")
            {
                Si = new Arbol("¿Tiene dolor de garganta?");
                No = new Arbol("¿Tiene secreción nasal espesa y verde?");
                Si.InicializarArbol();
                No.InicializarArbol(); 
            }
            else if (Pregunta == "¿Tiene dolor de garganta?")
            {
                Si = new Arbol("¿?");
                No = new Arbol("¿?");
                Si.InicializarArbol(); 
                No.InicializarArbol(); 
            }




            //Preguntas de Sinusitis
            else if (Pregunta == "¿Ha experimentado dolor facial?")
            {
                Si = new Arbol("¿Siente presión en los senos paranasales?");
                No = new Arbol("¿Tiene dolor de cabeza?");
                Si.InicializarArbol(); 
                No.InicializarArbol(); 
            }
            else if (Pregunta == "¿Siente presión en los senos paranasales?")
            {
                Si = new Arbol("¿Tiene secreción nasal espesa y verde?");
                No = new Arbol("¿Siente fatiga o cansancio general?");
                Si.InicializarArbol(); 
                No.InicializarArbol(); 
            }
            else if (Pregunta == "¿Tiene secreción nasal espesa y verde?")
            {
                Si = new Arbol("¿?");
                No = new Arbol("¿Tiene dolor de garganta?");
                Si.InicializarArbol();
                No.InicializarArbol();
            }




            //Unica Opcion sin Congestion Nasal
            //Preguntas de Bronquitis
            else if (Pregunta == "¿Se le ha presentado una tos persistente?")
            {
                Si = new Arbol("¿A observa producción de esputo al toser?");
                No = new Arbol("¿Tiene dolor de garganta?");
                Si.InicializarArbol(); 
                No.InicializarArbol();

                //Dar porcentajes
                datos.PorcentajeBronquitis += 20;
            }
            else if (Pregunta == "¿Ha observa producción de esputo al toser?")
            {
                Si = new Arbol("¿Ha tenido dificultades para respirar?");
                No = new Arbol("¿Tiene tos?");
                Si.InicializarArbol(); 
                No.InicializarArbol();
            }
            else if (Pregunta == "¿Ha tenido dificultades para respirar?")
            {
                Si = new Arbol("¿Ha experimentado dolor en el pecho?");
                No = new Arbol("¿Siente un leve malestar general?");
                Si.InicializarArbol(); 
                No.InicializarArbol(); 
            }
            else if (Pregunta == "¿Ha experimentado dolor en el pecho?")
            {
                Si = new Arbol("¿?");
                No = new Arbol("¿?");
                Si.InicializarArbol(); 
                No.InicializarArbol(); 

            }
        }
    }
}
