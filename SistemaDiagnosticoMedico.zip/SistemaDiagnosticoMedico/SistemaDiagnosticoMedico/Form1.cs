﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Referenciar el Metodo BLL
using BLL;

namespace SistemaDiagnosticoMedico
{
        
    public partial class Form1 : Form
    {
        //Variable Objeto del BLL
        private Datos datos = null;
        public Form1()
        {
            InitializeComponent();
            //Instanciar Objeto BLL
            datos = new Datos();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //Metodo del Boton para Salir del Programa
            if (MessageBox.Show("Desea salir del programa", "Confirmar",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) 
            {
                Application.Exit();
            }
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            //Condicional para avanzar al siguiente Panel tras LLenar los Datos
            if (!string.IsNullOrEmpty(txtNombre.Text) && !string.IsNullOrEmpty(txtApellido1.Text) && !string.IsNullOrEmpty(txtApellido2.Text))
            {
                //Enviar los Datos al Metodo BLL
                datos.NombreCompleto = txtNombre.Text +" "+ txtApellido1.Text +" "+ txtApellido2.Text;

                //Esconder el Panel Actual
                this.Hide();

                //Abrir el Panel de las Preguntas Enviando el Objeto datos
                FrmPreguntas Frm2 = new FrmPreguntas(datos);
                Frm2.Show();
            }
        }

        private void MostrarInterfazPreguntas()
        {
            
        }
    }
}
