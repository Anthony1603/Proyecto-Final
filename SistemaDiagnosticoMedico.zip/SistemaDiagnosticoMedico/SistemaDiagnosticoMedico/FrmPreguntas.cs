﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Referenciar el Metodo BLL
using BLL;

namespace SistemaDiagnosticoMedico
{
    public partial class FrmPreguntas : Form
    {
        //Declarar el Objeto datos
        private Datos datos;
        int numero = 0;

        //Declarar el Objeto Arbol
        private Arbol raiz;
        private Arbol nodoActual;
        public FrmPreguntas(Datos datos)
        {
            InitializeComponent();
            //Asignarle el Valor de Datos del Form1
            this.datos = datos;


            //Asignarle el Valor de la Primera Pregunta del Arbol
            raiz = new Arbol("¿Has experimentado congestión nasal?");

            // Inicializar el árbol
            raiz.InicializarArbol();

            //Establecer el Nodo Actual
            nodoActual = raiz;

            //LLamar al Metodo Pregunta Actual
            MostrarPreguntaActual();
        }

        private void MostrarPreguntaActual()
        {
            //Agrega las Preguntas en la TextBox
            txtPreguntas.Text = nodoActual.Pregunta;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //Boton para Salir del Programa
            if (MessageBox.Show("Desea salir del programa", "Confirmar",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSi_Click(object sender, EventArgs e)
        {
            //Condicional para Revisar si aun hay mas Nodos Hijos en la Direccion Si
            if (nodoActual.Si != null)
            {
                //Actualizar Nodo a Si
                nodoActual = nodoActual.Si;

                MostrarPreguntaActual();
            }
            else
            {
                //Se Llego a una conclusión
                MessageBox.Show("Llegaste a una conclusión.");

                //Esconder el Panel Actual
                this.Hide();

                //Abrir el Panel del Diagnostico Enviando el Objeto datos
                FrmDiagnostico Diagnostico = new FrmDiagnostico(datos);
                Diagnostico.Show();

            }
        }

        private void FrmPreguntas_Load(object sender, EventArgs e)
        {
         
        }

        private void btnNo_Click(object sender, EventArgs e)
        {
            //Condicional para Revisar si aun hay mas Nodos Hijos en la Direccion No
            if (nodoActual.No != null)
            {
                //Actualizar Nodo a No
                nodoActual = nodoActual.No;
                MostrarPreguntaActual();
            }
            else
            {
                //Se Llego a una conclusión
                MessageBox.Show("Llegaste a una conclusión.");

                //Esconder el Panel Actual
                this.Hide();

                //Abrir el Panel del Diagnostico Enviando el Objeto datos
                FrmDiagnostico Diagnostico = new FrmDiagnostico(datos);
                Diagnostico.Show();
            }
        }
    }
}
