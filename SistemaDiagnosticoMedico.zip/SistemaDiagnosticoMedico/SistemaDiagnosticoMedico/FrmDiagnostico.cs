﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Referenciar el Metodo BLL
using BLL;

namespace SistemaDiagnosticoMedico
{
    public partial class FrmDiagnostico : Form
    {
        //Declarar el Objeto datos
        private Datos datos;


        public FrmDiagnostico(Datos datos)
        {
            InitializeComponent();
            //Asignarle el Valor de datos del Form1
            this.datos = datos;
            
        }

        public void LlamarDatos()
        {
            //Colocar el Nombre digitado en Form1 en la TextBox
            txtNombreCompleto.Text = datos.NombreCompleto;
            txtSintomas.Text = datos.Sintomas;
            txtEnfermedades.Text = $"{datos.PorcentajeMaximo}% de posibilidad de {datos.Enfermedad}";
            txtTratamiento.Text = datos.Tratamiento;
        }
        private void FrmDiagnostico_Load(object sender, EventArgs e)
        {
            //LLamar al Metodo del BLL Datos para Calcular los Porcentajes
            datos.CompararPorcentaje();
            LlamarDatos();
        }


        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //Boton para Salir del Programa
            if (MessageBox.Show("Desea salir del programa", "Confirmar",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
